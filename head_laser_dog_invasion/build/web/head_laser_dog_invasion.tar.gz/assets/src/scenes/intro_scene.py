import pygame
from src.config import SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_BG
from src.ui.text import draw_text
from src.utils.assets import get_font

class IntroScene:
    def __init__(self, game):
        self.game = game
        self.timer = 0
        self.scale = 0.1
        self.done_animating = False

    def on_enter(self):
        self.timer = 0
        self.scale = 0.1
        self.done_animating = False

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
            if self.done_animating:
                self.game.change_scene("menu")

    def update(self, dt):
        self.timer += dt
        if self.scale < 1.0:
            self.scale += 0.01
        else:
            self.done_animating = True

    def draw(self, screen):
        screen.fill(COLOR_BG)
        font = get_font(int(40 * self.scale))
        text_surf = font.render("DESARROLLADO POR ANTHONY GUARDADO", True, (0, 255, 0))
        rect = text_surf.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
        screen.blit(text_surf, rect)

        if self.done_animating:
            draw_text(screen, "Presiona cualquier tecla para continuar", 20, SCREEN_WIDTH//2, SCREEN_HEIGHT - 50)