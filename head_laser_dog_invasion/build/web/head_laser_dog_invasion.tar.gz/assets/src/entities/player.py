import pygame
from src.config import SCREEN_WIDTH, SCREEN_HEIGHT, COLOR_WHITE, COLOR_GREEN
from src.entities.laser import Laser
from src.utils.sound import play_sound

class Player:
    def __init__(self):
        self.radius = 20
        self.x = SCREEN_WIDTH // 2
        self.y = SCREEN_HEIGHT - 40
        self.speed = 5
        self.cooldown = 0

    def update(self, dt):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.x -= self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.x += self.speed
            
        self.x = max(self.radius, min(SCREEN_WIDTH - self.radius, self.x))
        
        if self.cooldown > 0:
            self.cooldown -= dt

    def shoot(self):
        if self.cooldown <= 0:
            self.cooldown = 250  # 250 ms cooldown
            play_sound("laser")
            return Laser(self.x, self.y - self.radius, -8)
        return None

    def draw(self, surface):
        pygame.draw.circle(surface, COLOR_WHITE, (int(self.x), int(self.y)), self.radius)
        # Ojos/detalles verdes
        pygame.draw.circle(surface, COLOR_GREEN, (int(self.x - 7), int(self.y - 5)), 4)
        pygame.draw.circle(surface, COLOR_GREEN, (int(self.x + 7), int(self.y - 5)), 4)

    def get_rect(self):
        return pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius*2, self.radius*2)