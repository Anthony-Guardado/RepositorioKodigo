import asyncio
import pygame
from src.game import Game
from src.config import SCREEN_WIDTH, SCREEN_HEIGHT, FPS

async def main():
    # Inicialización de Pygame y el Mixer
    pygame.init()
    pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
    
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("HEAD LASER: DOG INVASION")
    
    clock = pygame.time.Clock()
    game = Game(screen)
    
    # Bucle principal compatible con pygbag
    running = True
    while running:
        dt = clock.tick(FPS)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            game.handle_event(event)
            
        game.update(dt)
        game.draw(screen)
        pygame.display.flip()
        
        # OBLIGATORIO para pygbag (libera el control al navegador)
        await asyncio.sleep(0)
        
    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())